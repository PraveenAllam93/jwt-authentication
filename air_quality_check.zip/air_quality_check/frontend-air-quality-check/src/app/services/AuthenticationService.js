import axios from "axios";

/* interacts with the backend service and helps to create an account or login to the exsisting account */
class AuthenticationService {
    signin = (username, password, firstname, lastname, email) => {
        return axios.post("/aqms/signin", {username, password, firstname, lastname, email})
            .then(response => {
                if (response.data.accessToken) {
                    localStorage.setItem("user", JSON.stringify(response.data));
                }
                return response.data;
            })
            .catch(err => {
                console.log(err);
                throw err;
            });
    }

    signOut() {
        localStorage.removeItem("user");
    }

    register = async(firstname, lastname, username, email, password) => {
        return axios.post("/aqms/signup", {
            firstname,
            lastname,
            username,
            email,
            password
        });
    }

    getCurrentUser() {
        return JSON.parse(localStorage.getItem('user'));;
    }
}

export default new AuthenticationService();