import axios from 'axios';

/* with the help of access token, the user can access all other services from the backend  */
axios.interceptors.request.use( config => {
    const user = JSON.parse(localStorage.getItem('user'));

    if(user && user.accessToken){
        const token = 'Bearer ' + user.accessToken;
        config.headers.Authorization =  token;
    }

    return config;
});

class BackendService {


    async getAllData() {
        return await axios.get("/airQualityInfo");
    }

    async getRawData() {
        return await axios.get("/data");
    }

    async getFirstFloor() {
        return await axios.get("/firstFloor");
    }

    async getSecondFloor() {
        return await axios.get("/secondFloor");
    }

    async getThirdFloor() {
        return await axios.get("/thirdFloor");
    }
}

export default new BackendService();