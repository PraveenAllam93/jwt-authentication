import React from 'react'
import FirstFloor from './FirstFloor'

describe('<FirstFloor />', () => {
  it('renders', () => {
    // see: https://on.cypress.io/mounting-react
    cy.mount(<FirstFloor />)
  })
})