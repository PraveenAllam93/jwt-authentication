import React, { Component } from 'react';
import AppNavbar from './AppNavbar';
import { Container } from 'reactstrap';
import { Form, Alert, FormGroup, Input, Label, Row, Col } from "reactstrap";
import {Button} from 'react-bootstrap';
import AuthenticationService from "../services/AuthenticationService";

import '../../App.css';

class Login extends Component {
    /* A login page which takes username and password, verifies and logs you in with a token if credentials are correct */
    constructor(props) {
        super(props);
        this.state = {
            username: "",
            password: "",
            error: ""
        };
    }

    changeHandler = (event) => {
        let nam = event.target.name;
        let val = event.target.value;
        this.setState({[nam]: val});
    }
    /* pushes to profile page if creds are correct */
    doLogin = async (event) => {
        event.preventDefault();

        AuthenticationService
            .signin(this.state.username, 
                    this.state.password,
                    this.state.firstname,
                    this.state.lastname,
                    this.state.email)
        .then(
            () => {
            this.props.history.push('/profile');
            },
            error => {
            console.log("Login fail: error = { " + error.toString() + " }");
            this.setState({error: "Can not signin successfully ! Please check username/password again"});
            }
        );
    }

    render() {
        return ( 
            <div className = "form">
                <AppNavbar/>
            
                <Container fluid>
                    <Row style={{marginTop:"20px"}}>
                        <Col sm="12" md={{ size: 3, offset: 4 }}>

                            <div style={{marginTop:"20px"}}>
                                <Label for="welcome"><strong>Welcome, Hola!</strong></Label>
                            </div>

                            <div className='login-form'>
                                <div className="input-container">
                                    <Form  onSubmit={this.doLogin}>
                                        <FormGroup>
                                            <div className="input-container">
                                                <Label for="username"><strong>Username</strong></Label>
                                                <Input autoFocus 
                                                type="text"
                                                name="username" id="username"
                                                value={this.state.username}
                                                placeholder="Enter Username"
                                                autoComplete="username"
                                                onChange={this.changeHandler}
                                                />
                                            </div>
                                        </FormGroup>

                                        <FormGroup>
                                            <div className="input-container">
                                                <Label for="password"><strong>Password</strong></Label>
                                                <Input type="password" 
                                                name="password" id="password"
                                                value={this.state.password}
                                                placeholder="Enter Password"
                                                autoComplete="password"
                                                onChange={this.changeHandler}
                                                />
                                            </div>
                                        </FormGroup>

                                        <div className="button-container">
                                            <Button type="submit" variant="primary" size="lg" block>
                                                Sign In
                                            </Button>
                                        </div>
                                
                                        {
                                            this.state.error && (
                                            <Alert color="danger">
                                                {this.state.error}
                                            </Alert>
                                            )
                                        }
                                    </Form>
                                </div>
                            </div>
                        </Col>
                    </Row>
                </Container>
                
            </div>
        );
    }
}

export default Login;