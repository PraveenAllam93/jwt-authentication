import AppNavbar from './AppNavbar';
import React, { Component } from 'react';
import { Container, Row, Label, Col } from 'reactstrap';
import BackendService from '../services/BackendService';
import '../../App.css';

/* uses a backend service to get all the data present in the all floors */
class AllData extends Component {

    constructor(props) {
        super(props);
        this.state = {
        items: [],
        };
    }

    /* stores the data in the form of json */
    componentDidMount() {
        BackendService.getAllData()
        .then((response) =>  this.setState({items: response.data}))
        
    };
  
    /* renders the json data */
    render() {
        const {items } = this.state;
        return (
            <div>
                <AppNavbar/>
                <Container fluid>
                    <Row style={{marginTop:"20px"}}>
                        <Col sm="12" md={{ size: 4, offset: 4 }}>
                            <div style={{marginTop:"20px"}}>
                                <Label for="welcome"><strong>AQI Data</strong></Label> {

                                    items.map((item) => ( 
                                        <ol key = { item.id } >
                                            <div style={{marginTop:"20px"}} className='login-form'> 
                                                <div style={{marginTop:"10px"}}> 
                                                    <Label for="id"><strong>Id:{ "  " +item.id}</strong></Label>
                                                </div>
                                                <div style={{marginTop:"10px"}}> 
                                                    <Label for="floor"><strong>Floor:{ "  " +item.floor}</strong></Label>
                                                </div>
                                                <div style={{marginTop:"10px"}}>      
                                                    <Label for="o2_level"><strong>Oxygen Level:{ "  " + item.o2_level}</strong></Label>
                                                </div>
                                                <div style={{marginTop:"10px"}}>
                                                    <Label for="co2_level"><strong>CO2 level:{ "  " + item.co2_level}</strong></Label>
                                                </div>
                                                <div style={{marginTop:"10px"}}>    
                                                    <Label for="so2_level"><strong>SO2 level:{"  " + item.so2_level}</strong></Label>
                                                </div>
                                                <div style={{marginTop:"10px"}}>      
                                                    <Label for="co_level"><strong>CO level:{ "  " + item.co_level}</strong></Label>
                                                </div>
                                                <div style={{marginTop:"10px"}}>
                                                    <Label for="c_level"><strong>C level:{ "  " + item.c_level}</strong></Label>
                                                </div>
                                                <div style={{marginTop:"10px"}}>    
                                                    <Label for="air_quality_level"><strong>AQI:{"  " + item.air_quality_level}</strong></Label>
                                                </div>
                                            </div>
                                        </ol>
                                    ))

                                }

                            </div>
                        </Col>
                    </Row>
                </Container>
             </div>
        );
    }
}

export default AllData;