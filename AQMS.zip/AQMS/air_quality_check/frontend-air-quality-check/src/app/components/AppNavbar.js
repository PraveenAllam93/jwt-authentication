import React, { Component } from 'react';
import { Collapse, Nav, Navbar, NavbarToggler, NavItem, NavLink } from 'reactstrap';
import { withRouter } from 'react-router-dom';
import '../../App.css';

import AuthenticationService from '../services/AuthenticationService';

/* App NavBar which contains the navigation options like sigin, signup, signout*/

class AppNavbar extends Component {
    constructor(props) {
        super(props);
        this.state = {isOpen: false};
        this.toggle = this.toggle.bind(this);

        this.state = {
            showUser: false,
            username: undefined,
            login: false
        };
    }

    componentDidMount() {
        const user = AuthenticationService.getCurrentUser();

        if (user) {
        const roles = [];

        user.authorities.forEach(authority => {
            roles.push(authority.authority)
        });
    
        this.setState({
            showUser: true,
            login: true,
            username: user.username
        });
        }
    } 

    signOut = () => {
        AuthenticationService.signOut();
        this.props.history.push('/signin');
        window.location.reload();
    }

    toggle() {
        this.setState({
        isOpen: !this.state.isOpen
        });
    }

    render() {
        return <Navbar color="dark" dark expand="md">
            <Nav className="mr-auto" >
                <NavLink href="/profile" className="nav-container">Profile</NavLink>
                {this.state.showUser && <NavLink href="/firstFloor" className="nav-container">First Floor</NavLink>}
                {this.state.showUser && <NavLink href="/secondFloor" className="nav-container">Second Floor</NavLink>}
                {this.state.showUser && <NavLink href="/thirdFloor" className="nav-container">Third Floor</NavLink>}
                {this.state.showUser && <NavLink href="/allData" className="nav-container">All Data</NavLink>}
            </Nav>
            <NavbarToggler onClick={this.toggle}/>
            <Collapse isOpen={this.state.isOpen} navbar> {
                this.state.login ? (
                    <Nav className="ml-auto" navbar>
                        <NavItem>
                            <NavLink href="#" onClick={this.signOut}  >SignOut ?
                            <text>{" " + this.state.username}</text></NavLink>
                        </NavItem>
                    </Nav>                 
                ) : (
                    <Nav className="ml-auto" navbar>
                        <NavItem>
                            <NavLink href="/signin" className='nav-actions'>Login</NavLink>
                        </NavItem>
                        <NavItem>
                            <NavLink href="/signup" className='nav-actions'>SignUp</NavLink>
                        </NavItem>
                    </Nav>
                )
            }
            </Collapse>
        </Navbar>;
    }
}

export default withRouter(AppNavbar);