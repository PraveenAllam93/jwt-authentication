import React from 'react'
import AllData from './AllData'

describe('<AllData />', () => {
  it('renders', () => {
    // see: https://on.cypress.io/mounting-react
    cy.mount(<AllData />)
  })
})