import React, { Component } from 'react';
import AppNavbar from './AppNavbar';
import { Link } from 'react-router-dom';
import { Button, Container, Label, Row, Col } from 'reactstrap';
import avatar from '../../avatar.png';

import '../../App.css';
import AuthenticationService from '../services/AuthenticationService';

/* gets the details of current user using jwt token and display the user details */
class Profile extends Component {

    constructor(props) {
        super(props);
        this.state = {user: undefined};
    }

    componentDidMount() {
        const user = AuthenticationService.getCurrentUser();
        this.setState({user: user});
    }

    render() {
        let userInfo = "";
        const user = this.state.user;

        // login
        if (user && user.accessToken) {

            let roles = "";
            user.authorities.forEach(authority => {
                roles = roles + " " + authority.authority
            });

            userInfo = (
                <Container fluid>
                    <Row style={{marginTop:"20px"}}>
                        <Col sm="12" md={{ size: 4, offset: 4 }}>

                            <div style={{marginTop:"20px"}}>
                
                                <Label for="welcome"><strong>Hello,{user.firstname + " " + user.lastname} :-)</strong></Label>
                        
                                <div style={{marginTop:"20px"}} className='login-form'>
                                    <img src={avatar} alt="Avatar" className="avatar center" 
                                    style={{width: "50%", height: "auto"}}/>

                                    <div style={{marginTop:"10px"}}> 
                                        <Label for="firstname"><strong>First Name:{ "  " +user.firstname}</strong></Label>
                                    </div>

                                    <div style={{marginTop:"10px"}}>      
                                        <Label for="lastname"><strong>Last Name:{ "  " + user.lastname}</strong></Label>
                                    </div>

                                    <div style={{marginTop:"10px"}}>
                                        <Label for="email"><strong>email:{ "  " + user.email}</strong></Label>
                                    </div>

                                    <div style={{marginTop:"10px"}}>    
                                        <Label for="username"><strong>Username:{"  " + user.username}</strong></Label>
                                    </div>
                                </div>
                            </div>
                        </Col>
                    </Row>
                </Container>
            );
        } else { // not login
            userInfo = <Container fluid>
                            <Row style={{marginTop:"20px"}}>
                                <Col sm="12" md={{ size: 4, offset: 4 }}>

                                    <div style={{marginTop:"20px"}} className='login-form'> 

                                        <div style={{marginTop:"20px"}}>
                                            <Label for="welcome"><strong>Hola, Please do Login :-)</strong></Label>
                                        </div>

                                        <div className="button-container">
                                        <Button color="success" size="lg" block><Link to="/signin"><span style={{color:"white"}} >Login</span></Link></Button>
                                        </div>
                                    </div>
                                </Col>
                            </Row>
                        </Container>   

                    
        }

        return (
            <div>
                <AppNavbar/>
                <Container fluid>
                {userInfo}
                </Container>
            </div>
        );
    }
}

export default Profile;