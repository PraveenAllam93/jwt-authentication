describe('FirstFloor.cy.js', () => {
  it('playground', () => {
    // cy.mount()
  })
})