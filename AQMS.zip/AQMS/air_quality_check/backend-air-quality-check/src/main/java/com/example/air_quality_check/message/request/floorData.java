package com.example.air_quality_check.message.request;

/* Floor data body */
public class floorData {

    public int floor;

    public int getFloor() {
        return floor;
    }

    public void setFloor(int floor) {
        this.floor = floor;
    }

}
